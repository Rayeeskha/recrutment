<!--Start Watch Video Area-->
<div class="watch-video-area">
    <div class="container">
        <div class="video-img">
            <img src="assets/images/video-img/video-img-1.jpg" alt="Image">
            <div class="video-content">
                <h3>Watch Our Working Video</h3>
                <div class="play-btn">
                    <a class="popup-youtube play-btn" href="https://www.youtube.com/watch?v=6WQCJx_vEX4">
                    <img src="assets/images/icon/icon-1.png" alt="Icon">
                    </a>
                </div>
            </div>
        </div>
    </div>
</div><br><br>
<!--End Watch Video Area--><?php /**PATH G:\xampp2022\htdocs\recrutment-laravel-projects\resources\views/components/frontend/startvideo.blade.php ENDPATH**/ ?>