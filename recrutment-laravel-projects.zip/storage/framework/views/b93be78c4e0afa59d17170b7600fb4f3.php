<!--Start Partner Area-->
<div class="partner-area">
    <div class="container">
        <div class="parner-overly">
            <div class="partner-slider owl-carousel owl-theme">
                <div class="parner-logo">
                    <a href="#"><img src="assets/images/partner/partner-logo-1.png" alt="Image"></a>
                </div>
                <div class="parner-logo">
                    <a href="#"><img src="assets/images/partner/partner-logo-2.png" alt="Image"></a>
                </div>
                <div class="parner-logo">
                    <a href="#"><img src="assets/images/partner/partner-logo-3.png" alt="Image"></a>
                </div>
                <div class="parner-logo">
                    <a href="#"><img src="assets/images/partner/partner-logo-4.png" alt="Image"></a>
                </div>
                <div class="parner-logo">
                    <a href="#"><img src="assets/images/partner/partner-logo-5.png" alt="Image"></a>
                </div>
                
            </div>
        </div>
    </div>
</div>
<!--End Partner Area--><?php /**PATH G:\xampp2022\htdocs\recrutment-laravel-projects\resources\views/components/frontend/partner.blade.php ENDPATH**/ ?>