<?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'backend.layouts.app','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<div class="row">
  <div class="col-12">
     <div class="page-title-box d-sm-flex align-items-center justify-content-between">
        <h4 class="mb-sm-0">Services</h4>
        <div class="page-title-right">
           <ol class="breadcrumb m-0">
              <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboards</a></li>
              <li class="breadcrumb-item active">Add Services</li>
           </ol>
        </div>
     </div>
  </div>
</div>
<div class="row">
	<div class="col-md-12">
		<div class="card">
			<div class="card-header">
				<h4 class="card-title mb-0 flex-grow-1">Add Service</h4>
			</div>
			<form class="validateForm" action="<?php echo e(route('admin.our-services.store')); ?>" method="post" enctype="multipart/form-data">
				<div class="card-body">
					<div class="row">
						<div class="col-md-6">
							<label for="labelInput" class="form-label">Title En</label>
	                        <input type="text" name="title_en" class="form-control" >
	                        <span class="text-danger Errtitle_en"></span>
						</div>
						<div class="col-md-6">
							<label for="labelInput" class="form-label" >Title Ar</label>
	                        <input type="text" name="title_ar" class="form-control" dir="rtl">
	                        <span class="text-danger Errtitle_ar"></span>
						</div>
						<div class="col-md-12">
							<label for="labelInput" class="form-label">Description English</label>

							<textarea class="ckeditor-classic" name="desc_en" ></textarea>
							<span class="text-danger Errdesc_en"></span>
	                    </div>
					</div>
				</div><br>
				<div class="card-footer">
					<div class="hstack gap-2 justify-content-end">
	                <?php if (isset($component)) { $__componentOriginal91d145e1fe435539cb537066f93d3aa6 = $component; } ?>
<?php $component = App\View\Components\Backend\Preloader::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.preloader'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Preloader::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91d145e1fe435539cb537066f93d3aa6)): ?>
<?php $component = $__componentOriginal91d145e1fe435539cb537066f93d3aa6; ?>
<?php unset($__componentOriginal91d145e1fe435539cb537066f93d3aa6); ?>
<?php endif; ?>
	                 <button type="submit" class="btn btn-success" id="add-btn"><span class=" las la-plus-circle"></span>&nbsp;Save</button>
	              </div>
				</div>
			</form>			
		</div>
	</div>
</div>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?><?php /**PATH G:\xampp2022\htdocs\recrutment-laravel-projects\resources\views/backend/our_services/create.blade.php ENDPATH**/ ?>