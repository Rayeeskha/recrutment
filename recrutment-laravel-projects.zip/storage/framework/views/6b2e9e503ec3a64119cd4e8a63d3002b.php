<div class="formPreloader" style="display: none;">
 	<img src="<?php echo e(asset('backend/assets/preloader/loader2.gif')); ?>" style="height: 100px; width: auto;">
</div><?php /**PATH G:\xampp2022\htdocs\recrutment-laravel-projects\resources\views/components/backend/preloader.blade.php ENDPATH**/ ?>