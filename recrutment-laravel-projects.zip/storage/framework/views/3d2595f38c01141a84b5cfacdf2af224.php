<div class="container">
	<div class="row">
		<div class="col-md-6" >
			<a href="#!">
				<div style="background-image: url('<?php echo e(asset('assets/images/persional/web/intern.jpg')); ?>');width: 100%;height: 400px; background-repeat: no-repeat;">
					<h1 style="padding-top: 40%;margin-left: 30px; ">
						<?php echo e(GoogleTranslate::trans('Internal Source', session()->get('locale'))); ?>

					</h1>
				</div>
			</a>
		</div>
		<div class="col-md-6">
			<a href="#!">
				<div style="background-image: url('<?php echo e(asset('assets/images/persional/web/extern.jpg')); ?>');width: 100%;height: 400px; background-repeat: no-repeat;">			
					<h1 style="padding-top: 40%;margin-left: 30px; ">
						<?php echo e(GoogleTranslate::trans('External Source', session()->get('locale'))); ?>

					</h1>
				</div>
			</a>
		</div>
	</div>
</div><br><br><?php /**PATH G:\xampp2022\htdocs\recrutment-laravel-projects\resources\views/components/frontend/employementsource.blade.php ENDPATH**/ ?>