
<?php $__env->startSection('page_title','MS International'); ?>
<?php $__env->startSection('meta_keywords','MS International'); ?>
<?php $__env->startSection('meta_description', 'MS International'); ?>
<?php $__env->startSection('container'); ?>

<!-- Banner -->
<?php if (isset($component)) { $__componentOriginal87ceddcbf94d2fab66dc139ed68704eb = $component; } ?>
<?php $component = App\View\Components\Frontend\Slider::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('frontend.slider'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Frontend\Slider::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal87ceddcbf94d2fab66dc139ed68704eb)): ?>
<?php $component = $__componentOriginal87ceddcbf94d2fab66dc139ed68704eb; ?>
<?php unset($__componentOriginal87ceddcbf94d2fab66dc139ed68704eb); ?>
<?php endif; ?>

<!-- Partner -->


<!-- About us -->
<?php if (isset($component)) { $__componentOriginala238ffcd8811a9cf90182abbd6041f10 = $component; } ?>
<?php $component = App\View\Components\Frontend\Aboutus::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('frontend.aboutus'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Frontend\Aboutus::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala238ffcd8811a9cf90182abbd6041f10)): ?>
<?php $component = $__componentOriginala238ffcd8811a9cf90182abbd6041f10; ?>
<?php unset($__componentOriginala238ffcd8811a9cf90182abbd6041f10); ?>
<?php endif; ?>

<!-- Services -->


<!-- Our Vision -->
<?php if (isset($component)) { $__componentOriginald0d021cd808e288bbe9cec765bdc20fc = $component; } ?>
<?php $component = App\View\Components\Frontend\Ourvision::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('frontend.ourvision'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Frontend\Ourvision::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald0d021cd808e288bbe9cec765bdc20fc)): ?>
<?php $component = $__componentOriginald0d021cd808e288bbe9cec765bdc20fc; ?>
<?php unset($__componentOriginald0d021cd808e288bbe9cec765bdc20fc); ?>
<?php endif; ?>

<!-- Our Basic Value -->
<?php if (isset($component)) { $__componentOriginalf9315fa85939e83a81739916a0b588f9 = $component; } ?>
<?php $component = App\View\Components\Frontend\Basicvalue::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('frontend.basicvalue'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Frontend\Basicvalue::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf9315fa85939e83a81739916a0b588f9)): ?>
<?php $component = $__componentOriginalf9315fa85939e83a81739916a0b588f9; ?>
<?php unset($__componentOriginalf9315fa85939e83a81739916a0b588f9); ?>
<?php endif; ?>

<!-- Why choose -->
<?php if (isset($component)) { $__componentOriginal285ccf6e9466d5352222ecaefa197cbb = $component; } ?>
<?php $component = App\View\Components\Frontend\Whychooseus::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('frontend.whychooseus'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Frontend\Whychooseus::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal285ccf6e9466d5352222ecaefa197cbb)): ?>
<?php $component = $__componentOriginal285ccf6e9466d5352222ecaefa197cbb; ?>
<?php unset($__componentOriginal285ccf6e9466d5352222ecaefa197cbb); ?>
<?php endif; ?>

<!-- Work step -->
<?php if (isset($component)) { $__componentOriginal5c800e60512109dd191a7199931cc8bc = $component; } ?>
<?php $component = App\View\Components\Frontend\Worksstep::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('frontend.worksstep'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Frontend\Worksstep::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5c800e60512109dd191a7199931cc8bc)): ?>
<?php $component = $__componentOriginal5c800e60512109dd191a7199931cc8bc; ?>
<?php unset($__componentOriginal5c800e60512109dd191a7199931cc8bc); ?>
<?php endif; ?>

<!-- Employee souce -->
<?php if (isset($component)) { $__componentOriginal634805f6f022fc3822fc80ad88c38068 = $component; } ?>
<?php $component = App\View\Components\Frontend\Employementsource::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('frontend.employementsource'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Frontend\Employementsource::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal634805f6f022fc3822fc80ad88c38068)): ?>
<?php $component = $__componentOriginal634805f6f022fc3822fc80ad88c38068; ?>
<?php unset($__componentOriginal634805f6f022fc3822fc80ad88c38068); ?>
<?php endif; ?>



<!-- Reviews -->


<!-- Team member -->




<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp2022\htdocs\recrutment-laravel-projects\resources\views/frontend/index.blade.php ENDPATH**/ ?>