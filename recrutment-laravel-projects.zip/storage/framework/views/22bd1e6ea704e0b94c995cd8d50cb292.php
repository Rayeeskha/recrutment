
<?php $__env->startSection('page_title', GoogleTranslate::trans('wakaala', session()->get('locale'))); ?>
<?php $__env->startSection('meta_keywords', GoogleTranslate::trans('wakaala', session()->get('locale'))); ?>
<?php $__env->startSection('meta_description',  GoogleTranslate::trans('wakaala', session()->get('locale'))); ?>
<?php $__env->startSection('container'); ?>

<div class="page-header-area bg-f4fbf6">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6 col-md-6">
                <div class="page-header-content">
                    <h1><?php echo e(GoogleTranslate::trans('wakaala', session()->get('locale'))); ?></h1>
                    <ul>
                        <li><a href="/"><?php echo e(GoogleTranslate::trans('Home', session()->get('locale'))); ?></a></li>
                        <li><?php echo e(GoogleTranslate::trans('wakaala', session()->get('locale'))); ?></li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-6 col-md-6">
                <div class="page-header-image">
                    <img src="<?php echo e(asset('assets/images/banner/banner-img-3.png')); ?>" alt="Image">
                </div>
            </div>
        </div>

        <div class="page-header-shape">
            <img src="<?php echo e(asset('assets/images/shape/shape-8.png')); ?>" alt="Image">
            <img src="<?php echo e(asset('assets/images/shape/shape-9.png')); ?>" alt="Image">
            <img src="<?php echo e(asset('assets/images/shape/shape-10.png')); ?>" alt="Image">
        </div>
    </div>
</div>

<div class="service-details-area pt-100 pb-70">
    <div class="container">
    	<center>
    		<h1><?php echo e(GoogleTranslate::trans('wakaala', session()->get('locale'))); ?></h1>
    	</center>
    	<div class="row">
    		<div class="col-md-2"> </div>
    		<div class="col-md-8">
    			<img src="<?php echo e(asset('assets/images/persional/wakaala.jpeg')); ?>" >
    		</div>
    		<div class="col-md-2"></div>
    	</div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp2022\htdocs\recrutment-laravel-projects\resources\views/frontend/services/wakaala.blade.php ENDPATH**/ ?>