<!-- Start About Area--> 
<div class="about-area style-2 ptb-100">          
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-4">
                <div class="about-image-content pr-15">
                    <img src="<?php echo e(asset('assets/images/persional/manager.jpeg')); ?>" alt="Image" width="350px" height="400px">
                </div>
            </div>
            <div class="col-lg-8">
                <div class="about-content pl-15">
                    <div class="about-title">
                        <!-- <span>About us</span> -->
                        <h2>Director </h2>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi lacus, dignissim phareta lorem. Sed ut lacus aliquet, volutpat sem pellentesque, egestas nisl.</p>
                    </div>

                    <div class="about-features">
                       <ul>
                           <li>
                               <div class="icon">
                                    <i class="ri-check-double-line"></i>
                               </div>
                               <h3>Permanent Placement & Managed Solutions</h3>
                           </li>
                           <li>
                                <div class="icon">
                                    <i class="ri-check-double-line"></i>
                                </div>
                                <h3>Contract Talent Solutions & Remote Hiring</h3>
                            </li>
                            <li>
                                <div class="icon">
                                    <i class="ri-check-double-line"></i>
                                </div>
                                <h3>Administrative & Customer Support</h3>
                            </li>
                            <li>
                                <div class="icon">
                                    <i class="ri-check-double-line"></i>
                                </div>
                                <h3>Marketing Creative & Finance Accounting</h3>
                            </li>
                       </ul>
                    </div>
                    <div class="experience">
                        <div class="icon">
                            <i class="flaticon-experience"></i>
                       </div>
                       <p>Over 20 Years’ Experience Providing Top Quality Carpentry Across World Lorem Ipsum Dolours Sit Amet Consectetur</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="about-area style-2 ptb-100">          
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-4">
                <div class="about-image-content pr-15">
                    <img src="<?php echo e(asset('assets/images/persional/director.jpeg')); ?>" alt="Image" width="350px" height="400px">
                </div>
            </div>
            <div class="col-lg-8">
                <div class="about-content pl-15">
                    <div class="about-title">
                        <h2>Marketing Manager </h2>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi lacus, dignissim phareta lorem. Sed ut lacus aliquet, volutpat sem pellentesque, egestas nisl.</p>
                    </div>

                    <div class="about-features">
                       <ul>
                           <li>
                               <div class="icon">
                                    <i class="ri-check-double-line"></i>
                               </div>
                               <h3>Permanent Placement & Managed Solutions</h3>
                           </li>
                           <li>
                                <div class="icon">
                                    <i class="ri-check-double-line"></i>
                                </div>
                                <h3>Contract Talent Solutions & Remote Hiring</h3>
                            </li>
                            <li>
                                <div class="icon">
                                    <i class="ri-check-double-line"></i>
                                </div>
                                <h3>Administrative & Customer Support</h3>
                            </li>
                            <li>
                                <div class="icon">
                                    <i class="ri-check-double-line"></i>
                                </div>
                                <h3>Marketing Creative & Finance Accounting</h3>
                            </li>
                       </ul>
                    </div>
                    <div class="experience">
                        <div class="icon">
                            <i class="flaticon-experience"></i>
                       </div>
                       <p>Over 20 Years’ Experience Providing Top Quality Carpentry Across World Lorem Ipsum Dolours Sit Amet Consectetur</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--End About Area<?php /**PATH G:\xampp2022\htdocs\recrutment-laravel-projects\resources\views/components/frontend/aboutus.blade.php ENDPATH**/ ?>