        <!-- Jquery js -->
        <script data-cfasync="false" src="{{ asset('scripts/5c5dd728/cloudflare-static/email-decode.min.js') }}"></script><script src="{{ asset('assets/js/jquery.min.js') }}"></script>
        <!-- Bootstrap bundle js -->
        <script src="{{ asset('assets/js/bootstrap.bundle.min.js') }}"></script>
        <!-- Meanmenu js -->
        <script src="{{ asset('assets/js/jquery.meanmenu.js') }}"></script>
        <!-- Owl Carosel js -->
        <script src="{{ asset('assets/js/owl.carousel.min.js') }}"></script>
        <!-- Magnific popup js -->
        <script src="{{ asset('assets/js/jquery.magnific-popup.js') }}"></script>
        <!-- Aos js -->
        <script src="{{ asset('assets/js/aos.js') }}"></script>
        <!-- Mixitup js -->
        <script src="{{ asset('assets/js/mixitup.min.js') }}"></script>
        <!-- Odometer js -->    
        <script src="{{ asset('assets/js/odometer.min.js') }}"></script>
        <!-- Appear js -->  
        <script src="{{ asset('assets/js/appear.min.js') }}"></script> 
        <!-- Form Validator js -->    
        <script src="{{ asset('assets/js/form-validator.min.js') }}"></script>
        <!-- Contact Form Script js -->    
        <script src="{{ asset('assets/js/contact-form-script.js') }}"></script>
        <!-- Ajaxchimp js -->    
        <script src="{{ asset('assets/js/ajaxchimp.min.js') }}"></script>
        <!--Custom js-->
        <script src="{{ asset('assets/js/custom.js') }}"></script>
    </body>
</html>