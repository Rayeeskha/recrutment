<x-frontend.css />
<x-frontend.header />
<x-frontend.navbar />

@section('container')			 
 	<!-- Page Wrapper -->
@show 

<x-frontend.footer />
<x-frontend.js />